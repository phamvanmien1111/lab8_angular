export interface IContact{
    firstName:String;
    lastName:String;
    email:String;
    message:String;
    purpose:String;
    createdAt:Date;
}