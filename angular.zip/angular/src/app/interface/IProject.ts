export interface Iproject{
    title: string;
    description: string;
    techStack:string[];
    image:string;
    link:string;
    createdAt: Date;
    imageproject:string[]
}